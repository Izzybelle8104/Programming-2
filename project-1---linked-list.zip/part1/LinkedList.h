//
// Created by ISABE on 2/28/2024.
//

#ifndef P1_LINKED_LISTS_LINKEDLIST_H
#define P1_LINKED_LISTS_LINKEDLIST_H
#include <vector>
#include <string>
#include <iostream>

using namespace std;


template<typename T>
class LinkedList {

//public variables ------------------------------------------------------
public:
    //Node
    struct Node{
        T data;

        Node* next;

        Node* prev;

        //No parameters constructor
        Node(){
            data = "";
            next = nullptr;
            prev = nullptr;
        }

        //Parameterized constructor
        Node(T data) {
            this->data = data;
            next = nullptr;
            prev = nullptr;
        }
    };

    // Big 3 stuff ------------------------------------------------------------------------

    //Default Constructor
    LinkedList(){
        head = nullptr;
        tail = nullptr;
        size = 0;
    }

//    //Copy Constructor
//    LinkedList(const LinkedList& other){
//
//    }

    //Destructor
    ~LinkedList(){
        Clear();
    }

    //Behaviors ------------------------------------------------------------------------

    void PrintForward() {
        Node* current = head;

        while (current != nullptr){
            cout << current->data << endl;
            current = current->next;
        }
    }

    void PrintReverse(){
        Node* current = tail;

        while (current != nullptr){
            cout << current->data << endl;
            current = current->prev;
        }

    }

    //void PrintForwardRecursive(Node* start);

    //void PrintReverseRecursive(Node* end);


    //Accessors ------------------------------------------------------------------------

    int NodeCount(){

        return size;
    }

    void FindAll(vector<Node*>& storage,const T& value) {
        //find nodes that match value and store a pointer to that node in th passed in vector
        Node *current = head;
        while (current != nullptr) {
            if (current->data == value){
                storage.push_back(current);
            }
            current = current->next;
        }
    }

    //Node* Find(const T& data)

    //Node* GetNode()

    Node* getHead(){

        return head;
    }

    Node* getTail(){

        return tail;
    }

    //Insertions ------------------------------------------------------------------------

    void AddHead(const T& data){
        if (size == 0) {
            head = new Node(data);
            tail = head;
        }

        else{
            Node* newNode = new Node(data);
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }

        size++;
    }

    void AddTail(const T& data){
        if (size == 0) {
            head = new Node(data);
            tail = head;
        }

        else{
            Node* newNode = new Node(data);
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }

        size++;

    }

    void AddNodesHead(const T* arr, int amount){
        for (int i=0; i < amount; i++){
            AddHead(arr[i]);
        }
    }

    void AddNodesTail(const T* arr, int amount){
        for (int i=0; i < amount; i++){
            AddTail(arr[i]);
        }
    }

    //InsertAfter();

    //InsertBefore();

    //InsertAt();


    // Removals ------------------------------------------------------------------------

    //RemoveHead();

    //RemoveTail();

    //Remove();

    //RemoveAt();

    void Clear(){
        Node* current = head;

        while (current != nullptr){
            Node* next = current->next;
            delete current;
            current = next;
        }
        head = nullptr;
        tail = nullptr;
        size = 0;
    }


    //Operators ------------------------------------------------------------------------

    //operator[];

    //operator=;

    //operator==;

//Private variables -----------------------------------------------------------------
private:
    Node* head;
    Node* tail;
    unsigned int size;


};
#endif //P1_LINKED_LISTS_LINKEDLIST_H
