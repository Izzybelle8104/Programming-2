//
// Created by ISABE on 2/28/2024.
//

#ifndef P1_LINKED_LISTS_LINKEDLIST_H
#define P1_LINKED_LISTS_LINKEDLIST_H
#include <vector>
#include <string>
#include <iostream>

using namespace std;


template<typename T>
class LinkedList {

//public variables ------------------------------------------------------
public:
    //Node
    struct Node{
        T data;

        Node* next;

        Node* prev;

        //No parameters constructor
        Node(){
            data = "";
            next = nullptr;
            prev = nullptr;
        }

        //Parameterized constructor
        Node(T data) {
            this->data = data;
            next = nullptr;
            prev = nullptr;
        }
    };

    // Big 3 stuff ------------------------------------------------------------------------

    //Default Constructor
    LinkedList(){
        head = nullptr;
        tail = nullptr;
        size = 0;
    }

    //Copy Constructor
    LinkedList(const LinkedList& other){
        //initialize
        this->size = 0;
        this->head = nullptr;
        this->tail = nullptr;

        //copy the nodes
        Node* current = other.head;
        while (current != nullptr) {
            AddTail(current->data);
            current = current->next;
        }

    }

    //Destructor
    ~LinkedList(){
        Clear();
    }

    //Behaviors ------------------------------------------------------------------------

    void PrintForward() {
        Node* current = head;

        while (current != nullptr){
            cout << current->data << endl;
            current = current->next;
        }
    }

    void PrintReverse(){
        Node* current = tail;

        while (current != nullptr){
            cout << current->data << endl;
            current = current->prev;
        }

    }

    //void PrintForwardRecursive(Node* start);

    //void PrintReverseRecursive(Node* end);


    //Accessors ------------------------------------------------------------------------

    int NodeCount(){

        return size;
    }

    void FindAll(vector<Node*>& storage,const T& value) {
        //find nodes that match value and store a pointer to that node in the passed in vector
        Node* current = head;
        while (current != nullptr) {
            if (current->data == value){
                storage.push_back(current);
            }
            current = current->next;
        }
    }

    Node* Find(const T& data) const{
        Node* current = head;
        while (current != nullptr) {
            if (current->data == data){
                return current;
            }
            current = current->next;
        }

        return nullptr;
}

    Node* GetNode(int index) const {
        if (index < 0 or index >= size){
            throw out_of_range("Index out of range");
        }

        Node* current = head;
            for (int i = 0; i < index; ++i) {
                current = current->next;
            }

        return current;
    }



    Node* getHead(){

        return head;
    }

    Node* getTail(){

        return tail;
    }

    //Insertions ------------------------------------------------------------------------

    void AddHead(const T& data){
        if (size == 0) {
            head = new Node(data);
            tail = head;
        }

        else{
            Node* newNode = new Node(data);
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }

        size++;
    }

    void AddTail(const T& data){
        if (size == 0) {
            head = new Node(data);
            tail = head;
        }

        else{
            Node* newNode = new Node(data);
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }

        size++;

    }

    void AddNodesHead(const T* arr, int amount){
        for (int i=0; i < amount; i++){
            AddHead(arr[i]);
        }
    }

    void AddNodesTail(const T* arr, int amount){
        for (int i=0; i < amount; i++){
            AddTail(arr[i]);
        }
    }

    //InsertAfter();

    //InsertBefore();

    //InsertAt();


    // Removals ------------------------------------------------------------------------

    //RemoveHead();

    //RemoveTail();

    //Remove();

    //RemoveAt();

    void Clear(){
        Node* current = head;

        while (current != nullptr){
            Node* next = current->next;
            delete current;
            current = next;
        }
        head = nullptr;
        tail = nullptr;
        size = 0;
    }


    //Operators ------------------------------------------------------------------------

    T& operator[](int index){
        Node* node = GetNode(index);

        return node->data;
    }

    LinkedList& operator=(const LinkedList& other){
        //self assignment
        if (this == &other){
            return *this;
        }

        //clean slate
        Clear();

        //copy the nodes
        Node* current = other.head;
        while (current != nullptr){
            AddTail(current->data);
            current = current->next;
        }

        }

    //operator==;

//Private variables -----------------------------------------------------------------
private:
    Node* head;
    Node* tail;
    unsigned int size{};


};
#endif //P1_LINKED_LISTS_LINKEDLIST_H
